//
//  Extension_UiImage.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

extension UIImage {
    struct homeList {
        static var addIncome            = UIImage(named: "add_income")
        static var addExpense           = UIImage(named: "add_expense")
        static var transaction          = UIImage(named: "transaction")
        static var reports              = UIImage(named: "reports")
        static var settings             = UIImage(named: "settings")
        static var logout               = UIImage(named: "logout")
    }
    
    struct navigationBarButton {
        static var more                 = UIImage(named: "more")
    }
}
