//
//  Extension_UIColor.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

extension UIColor {
    
    struct appColor {
        static var themeBackground               = UIColor(named: "app_theme_background")
        static var themeNavigationBarBackground  = UIColor(named: "app_theme_navigation_bar")
        static var homeCollectionViewCell        = UIColor(named: "app_home_collectionviewcell")
    }
}

