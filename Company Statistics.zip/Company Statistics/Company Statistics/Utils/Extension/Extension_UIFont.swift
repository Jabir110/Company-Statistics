//
//  Extension_UIFont.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

extension UIFont {
    
    struct AppFontType {
        static var Roboto_Regular       = "Roboto-Regular"
        static var Roboto_Medium        = "Roboto-Medium"
        static var Roboto_Bold          = "Roboto-Bold"
    }
    
    /// NunitoSans Regular
    class func appRegularFont(WithSize size:CGFloat, shouldResize:Bool = true) -> UIFont {
        return UIFont(name: AppFontType.Roboto_Regular, size: shouldResize ? size.proportionalFontSize() : size)!
        //return UIFont.systemFont(ofSize: shouldResize ? size.proportionalFontSize() : size)
    }
    
    /// NunitoSans Bold
    class func appBoldFont(WithSize size:CGFloat, shouldResize:Bool = true) -> UIFont {
        return UIFont(name: AppFontType.Roboto_Bold, size: shouldResize ? size.proportionalFontSize() : size)!
        //return UIFont.systemFont(ofSize: shouldResize ? size.proportionalFontSize() : size)
    }
    
    /// NunitoSans Medium
    class func appMediumFont(WithSize size:CGFloat, shouldResize:Bool = true) -> UIFont {
        return UIFont(name: AppFontType.Roboto_Medium, size: shouldResize ? size.proportionalFontSize() : size)!
        //return UIFont.systemFont(ofSize: shouldResize ? size.proportionalFontSize() : size)
    }
}
