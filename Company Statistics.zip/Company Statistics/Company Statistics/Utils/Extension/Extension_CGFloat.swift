//
//  Extension_CGFloat.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

extension CGFloat {
    
    /// Calculate size depend on device Ex. GFloat(15.0).proportionalFontSize()
    ///
    /// - Returns: new value
    public func proportionalFontSize() -> CGFloat {
        
        var sizeToCheckAgainst = self
        
        switch UIDevice.deviceType {
        case .iPhone4or4s:
            sizeToCheckAgainst -= 2
            break
        case .iPhone5or5s:
            sizeToCheckAgainst -= 1
            break
        case .iPhone6or6s:
            sizeToCheckAgainst -= 0
            break
        case .iPhone6por6sp:
            sizeToCheckAgainst += 1
            break
        case .iPhoneXorXs:
            sizeToCheckAgainst += 0
            break
        case .iPhoneXrorXsmax:
            sizeToCheckAgainst += 1
            break
        case .iPad:
            sizeToCheckAgainst += 10
            break
        }
        return sizeToCheckAgainst
    }
    
}
