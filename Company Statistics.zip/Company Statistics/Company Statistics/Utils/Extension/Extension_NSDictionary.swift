//
//  Extension_NSDictionary.swift
//
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation
import CoreGraphics

public extension NSDictionary {
	
    /// Json serialization
    ///
    /// - Returns: String
    func convertToString() -> String {
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: self, options: JSONSerialization.WritingOptions.prettyPrinted)
            return String(data: jsonData, encoding: String.Encoding.utf8)!
        } catch {
            return "{}"
        }
	}
	
    /// Validate Int value from object
    ///
    /// - Parameter aKey: key (string)
    /// - Returns: value (Int)
    func object_forKeyWithValidationForClass_Int(aKey: String) -> Int {
		
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return Int()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return Int()
			}
		} else {
			// KEY NOT FOUND
			return Int()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return Int()
		} else if let strVal = aValue as? String {
			return (strVal as NSString).integerValue
		} else {
			
			if let intVal = aValue as? Int {
				return intVal
			} else {
				return Int()
			}
		}
	}
	
    ///  Validate CGFloat value from object
    ///
    /// - Parameter aKey: Key(string)
    /// - Returns: your value (CGFloat)
    func object_forKeyWithValidationForClass_CGFloat(aKey: String) -> CGFloat {
		
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return CGFloat()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return CGFloat()
			}
		} else {
			// KEY NOT FOUND
			return CGFloat()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return CGFloat()
		} else {
			if let floatVal = aValue as? CGFloat {
				return floatVal
			} else {
				return CGFloat()
			}
		}
	}
	
    ///  Validate String value from object
    ///
    /// - Parameter aKey: Key(string)
    /// - Returns: your value (String)
    func object_forKeyWithValidationForClass_String(aKey: String) -> String {
		
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return String()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return String()
			}
		} else {
			// KEY NOT FOUND
			return String()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return String()
		} else if let numValue = aValue as? NSNumber {
			return String(format: "%f", numValue.doubleValue)
		} else {
			
			if let strVal = aValue as? String {
				return strVal
			} else {
				return String()
			}
		}
	}
	
    ///  Validate StringInt value from object
    ///
    /// - Parameter aKey: Key(string)
    /// - Returns: your value (String)
    func object_forKeyWithValidationForClass_StringInt(aKey: String) -> String {
		
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return String()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return String()
			}
		} else {
			// KEY NOT FOUND
			return String()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return String()
		} else if let numVal = aValue as? NSNumber {
			return String(format: "%d", numVal.int64Value)
		} else {
			if let strVal = aValue as? String {
				return strVal
			} else {
				return String()
			}
		}
	}
	
    ///  Validate Bool value from object
    ///
    /// - Parameter aKey: Key(string)
    /// - Returns: your value (Bool)
    func object_forKeyWithValidationForClass_Bool(aKey: String) -> Bool {
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return Bool()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return Bool()
			}
		} else {
			// KEY NOT FOUND
			return Bool()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return Bool()
		} else {
			if let boolVal = aValue as? Bool {
				return boolVal
			} else {
				return Bool()
			}
		}
	}
	
    ///  Validate Array from object
    ///
    /// - Parameter aKey: Key(string)
    /// - Returns: your value (NSArray)
    func object_forKeyWithValidationForClass_NSArray(aKey: String) -> NSArray {
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return NSArray()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return NSArray()
			}
		} else {
			// KEY NOT FOUND
			return NSArray()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return NSArray()
		} else {
			if let arrVal = aValue as? NSArray {
				return arrVal
			} else {
				return NSArray()
			}
		}
	}
	
    ///  Validate NSMutableArray value from object
    ///
    /// - Parameter aKey: Key(string)
    /// - Returns: your value (NSMutableArray)
    func object_forKeyWithValidationForClass_NSMutableArray(aKey: String) -> NSMutableArray {
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return NSMutableArray()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return NSMutableArray()
			}
		} else {
			// KEY NOT FOUND
			return NSMutableArray()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return NSMutableArray()
		} else {
			if let arrVal = aValue as? NSMutableArray {
				return arrVal
			} else {
				return NSMutableArray()
			}
		}
	}
	
    ///  Validate NSMutableArray value from object
    ///
    /// - Parameter aKey: Key(string)
    /// - Returns: your value (NSMutableArray)
    func object_forKeyWithValidationForClass_NSDictionary(aKey: String) -> NSDictionary {
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return NSDictionary()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return NSDictionary()
			}
		} else {
			// KEY NOT FOUND
			return NSDictionary()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return NSDictionary()
		} else {
			
			if let dictVal = aValue as? NSDictionary {
				return dictVal
			} else {
				return NSDictionary()
			}
		}
	}
	
    ///  Validate NSMutableDictionary value from object
    ///
    /// - Parameter aKey: Key(string)
    /// - Returns: your value (NSMutableDictionary)
    func object_forKeyWithValidationForClass_NSMutableDictionary(aKey: String) -> NSMutableDictionary {
		// CHECK FOR EMPTY
		if self.allKeys.count == 0 {
			return NSMutableDictionary()
		}
		
		// CHECK IF KEY EXIST
		if let val = self.object(forKey: aKey) {
			if (val as AnyObject).isEqual(NSNull()) {
				return NSMutableDictionary()
			}
		} else {
			// KEY NOT FOUND
			return NSMutableDictionary()
		}
		
		// CHECK FOR NIL VALUE
		let aValue: AnyObject = self.object(forKey: aKey)! as AnyObject
		if aValue.isEqual(NSNull()) {
			return NSMutableDictionary()
		} else {
			if let dictVal = aValue as? NSMutableDictionary {
				return dictVal
			} else {
				return NSMutableDictionary()
			}
		}
	}
}
