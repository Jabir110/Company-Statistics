//
//  Extension_UICollectionView.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

public extension UICollectionView {
    
    // Cell register
    func registerCell<T: UICollectionViewCell>(_: T.Type){
        self.register(T.nibName, forCellWithReuseIdentifier: T.className)
    }
    
    func dequeueReusableCell<T: UICollectionViewCell>(forIndexPath indexPath: IndexPath) -> T {
        guard let cell = dequeueReusableCell(withReuseIdentifier: T.className, for: indexPath) as? T else {
            fatalError("Could not dequeue cell with identifier: \(T.className)")
        }
        return cell
    }
    
    // Header register
    func registerHeader<T: UICollectionReusableView>(_: T.Type){
        self.register(T.nibName, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: T.className)
    }
    
    func dequeueReusableHeader<T: UICollectionReusableView>(_: T.Type,forIndexPath indexPath: IndexPath)-> T{
        let headerView = self.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: T.className, for: indexPath)
        return headerView as! T
        
    }
    
    // Footer register
    func registerFooter<T: UICollectionReusableView>(_: T.Type){
        self.register(T.nibName, forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: T.className)
    }
    func dequeueReusableFooter<T: UICollectionReusableView>(_: T.Type,forIndexPath indexPath: IndexPath)-> T{
        let footerView = self.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: T.className, for: indexPath)
        return footerView as! T
    }
}

extension NSObject {
    
    static public var className: String {
        return String(describing: self)
    }
    
    static public var nibName : UINib {
        return UINib(nibName: String(describing: self), bundle: nil)
    }
}
