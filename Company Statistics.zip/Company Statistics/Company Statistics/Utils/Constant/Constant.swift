//
//  Constant.swift
//  Company Statistics
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD

// MARK: - COMMON CONSTANT
public struct Constants {
    
    static let  appDelegate                 = UIApplication.shared.delegate as! AppDelegate
    static let  platform                    = "ios"
    static let  udid                        = UIDevice.current.identifierForVendor!.uuidString
    static let  SCREEN_HEIGHT               = UIScreen.main.bounds.size.height
    static let  SCREEN_WIDTH                = UIScreen.main.bounds.size.width
    static var  AppName                     = Bundle.main.infoDictionary![kCFBundleNameKey as String] as! String // App Name
    static var  AppBundleVersion            = Bundle.main.infoDictionary?["CFBundleVersion"] as! String // App Bundle number
    static var  AppVersion                  = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as AnyObject  // App Version
    static var  deviceModelName             = UIDevice.current.description    // Device Model Name
    static var  deviceVersionOS             = UIDevice.current.systemVersion  // Device Version Number
    static var  randomIdGenerationLength    = 6  // Device Version Number
    static var  deviceType                  = "1"  // 1 for iOS
}

// MARK: - STORYBOARD NAME
enum StoryboardName: String {
    case Main = "Main"
}

// MARK: - CUSTOM LOADER
public func showLoader() {
    OperationQueue.main.addOperation {
        SVProgressHUD.setDefaultMaskType(.gradient)
        SVProgressHUD.show()
    }
}

public func hideLoader() {
    OperationQueue.main.addOperation {
        SVProgressHUD.dismiss()
    }
}

// MARK: - USER DEFAULTS
public func setUserDefaultsFor(object:AnyObject, with key:String) {
    UserDefaults.standard.set(object, forKey: key)
    UserDefaults.standard.synchronize()
}

public func getUserDefaultsForKey(key:String) -> AnyObject? {
    return UserDefaults.standard.object(forKey: key) as AnyObject?
}

public func removeUserDefaultsFor(key:String) {
    UserDefaults.standard.removeObject(forKey: key)
    UserDefaults.standard.synchronize()
}

// MARK: - PROPORTIONAL SIZE
func GET_PROPORTIONAL_WIDTH(width: CGFloat) -> CGFloat {
    return CGFloat((Constants.SCREEN_WIDTH * width)/750)
}
func GET_PROPORTIONAL_HEIGHT(height: CGFloat) -> CGFloat {
    return CGFloat((Constants.SCREEN_HEIGHT * height)/1334)
}

// MARK: - INTERNET NOT AVILABLE ALERT
func AlertInternetNotAvailable() {
    UIAlertController.showAlert(withMessage: Messages.internetConnectionAlert) { (index) in }
}

// MARK: - CONVERT STRING FROM DICTIONARY
public func getStringFromDictionary(dict:Any) -> String{
    var strJson = ""
    do {
        let data = try JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions.prettyPrinted)
        strJson = String(data: data, encoding: String.Encoding.utf8)!
    } catch let error as NSError {
        print("json error: \(error.localizedDescription)")
    }
    return strJson
}
