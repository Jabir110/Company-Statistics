//
//  CompanyIncomeDeatailsViewController.swift
//  Company Statistics
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class IncomeDeatailsViewController: UIViewController {

    //MARK:- OUTLET
    @IBOutlet weak var incomeDeatailsTableView: IncomeDetailsTableVIew!
    
    // MARK: - PROPERTIES -
    var objCompany: Company = Company()

    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        self.callIncomeDetailsApiwith(objCompany: objCompany)
    }
    
    private func setupUI(){
        
        //NAVIGATION
        self.title = "Income Details"
    }
}

extension IncomeDeatailsViewController {

    //MARK:- APIS -
    func callIncomeDetailsApiwith(objCompany: Company) {
         
        var params: [String : Any] = [:]
        params["Ticker"] = objCompany.ticker

        ApiClient.callIncomeDetailsApi(params: params) { (status, response, message) in
            
            if status {
                self.incomeDeatailsTableView.arrIncomeDeatailsList = response
                self.incomeDeatailsTableView.reloadData()
            }
            else {
                print("Error: \(String(describing: message))")
            }
        }
    }
}
