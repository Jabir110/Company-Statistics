//
//  HomeViewController.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class CompanyListViewController: UIViewController {

    //MARK:- OUTLET
    @IBOutlet weak var companyListTableView: CompanyListTableView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        self.callCompanyListApiwith()
    }
    
    private func setupUI(){
        
        //NAVIGATION
        self.title = "Most Active Stocks"
        
        //BLOCK REGISTER
        self.companyListTableView.blockTableViewDidSelectAtIndexPath = { (objCompany) in
            let incomeDeatailsVC = IncomeDeatailsViewController.loadController(strStoryBoardName: StoryboardName.Main.rawValue)
            incomeDeatailsVC.objCompany = objCompany
            self.navigationController?.pushViewController(incomeDeatailsVC, animated: true)
        }
    }
}

extension CompanyListViewController {

    //MARK:- APIS -
    func callCompanyListApiwith() {
                
        ApiClient.callCompanyListApi(params: nil) { (status, response, message) in
            
            if status {
                self.companyListTableView.arrCompanyList = response
                self.companyListTableView.reloadData()
            }
            else {
                print("Error: \(String(describing: message))")
            }
        }
    }
}
