//
//  CompanyIncomeDetailsTableVIew.swift
//  Company Statistics
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class IncomeDetailsTableVIew: AITableView {
    
    // MARK:- PROPERTIES
    var arrIncomeDeatailsList: [IncomeDeatails] = []
    
    // MARK:- INIT METHODS
    override func awakeFromNib() {
        super.awakeFromNib()
        self.contentInset = UIEdgeInsets(top: 10.0, left: 0.0, bottom: 40.0, right: 0.0)
       
        // CONFIGURATION
        self.backgroundColor = UIColor.white
        self.estimatedRowHeight = 50.0
        self.rowHeight = UITableView.automaticDimension
        
        self.isPullToRefreshEnabled = false
    }
    
    // MARK:- TABLEVIEW DATASOURCE & DELEGATE METHODS
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrIncomeDeatailsList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: IncomeDetailsTableViewCell = self.dequeueReusableCell()
        cell.updateDate(objIncomeDetails: arrIncomeDeatailsList[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
