//
//  CompanyIncomeDetailsTableViewCell.swift
//  Company Statistics
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class IncomeDetailsTableViewCell: AITableViewCell {

    // MARK:- OUTLET
    @IBOutlet weak private var lblTitle: AILabel!
    @IBOutlet weak private var lbl2014_12: AILabel!
    @IBOutlet weak private var lbl2015_12: AILabel!
    @IBOutlet weak private var lbl2016_12: AILabel!
    @IBOutlet weak private var lbl2017_12: AILabel!
    @IBOutlet weak private var lbl2018_12: AILabel!
    @IBOutlet weak private var lblTtm: AILabel!
    @IBOutlet weak private var viewMain: UIView!

    // MARK:- INIT METHODS
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    // MARK:- SETUP UI & DATA
    private func setupUI(){
        viewMain.layer.cornerRadius = 5.0
    }
    
    func updateDate(objIncomeDetails: IncomeDeatails) {
        lblTitle.text = objIncomeDetails.title
        lbl2014_12.text = objIncomeDetails.v2014
        lbl2015_12.text = objIncomeDetails.v2015
        lbl2016_12.text = objIncomeDetails.v2016
        lbl2017_12.text = objIncomeDetails.v2017
        lbl2018_12.text = objIncomeDetails.v2018
        lblTtm.text = objIncomeDetails.vTtm
    }
}
