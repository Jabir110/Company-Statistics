//
//  CompanyListTableViewCell.swift
//  Company Statistics
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class CompanyListTableViewCell: AITableViewCell {

    // MARK:- OUTLET
    @IBOutlet weak private var lblCompanyName: AILabel!
    @IBOutlet weak private var lblTicker: AILabel!
    @IBOutlet weak private var lblPrice: AILabel!
    @IBOutlet weak private var lblChanges: AILabel!
    @IBOutlet weak private var lblChangesPrec: AILabel!
    @IBOutlet weak private var viewMain: UIView!

    // MARK:- INIT METHODS
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    // MARK:- SETUP UI & DATA
    private func setupUI() {
        viewMain.layer.cornerRadius = 5.0
    }
    
    func updateDate(objCompany: Company) {
        lblCompanyName.text = objCompany.companyName
        lblTicker.text = objCompany.ticker
        lblPrice.text = objCompany.price
        lblChanges.text = objCompany.changes
        lblChangesPrec.text = objCompany.changesPerc
    }
}
